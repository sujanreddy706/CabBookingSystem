package Cab;

public class Cab {
	String DriverName;
	String PhoneNumber;
	String NumberPlate;
	double Cost;
	Cab(String DriverName,String PhoneNumber,String NumberPlate,double Cost){
		this.DriverName=DriverName;
		this.PhoneNumber=PhoneNumber;
		this.NumberPlate=NumberPlate;
		this.Cost=Cost;
	}
}
